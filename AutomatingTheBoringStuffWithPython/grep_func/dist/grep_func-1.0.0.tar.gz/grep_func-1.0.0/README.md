NOTE: This is a test package to understand package management in python.

Provides grep style functinality to check for any functions present in any module.

